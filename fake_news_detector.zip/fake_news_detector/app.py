from flask import Flask, render_template, request
import pickle

model = pickle.load(open("fake_newsmodel.pkl", "rb"))
vectorizer = pickle.load(open("tfidf_vectorizer.pkl", "rb"))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    news = request.form['news']
    data = vectorizer.transform([news])
    prediction = model.predict(data)[0]
    label = "Real News" if prediction == 1 else " Fake News"
    return render_template("result.html", prediction_text=label)

if __name__ == "__main__":
    app.run(debug=True)
