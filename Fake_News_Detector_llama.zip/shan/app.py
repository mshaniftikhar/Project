from flask import Flask, render_template, request
from llama_api import check_fake_news

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        article = request.form["news_input"]

        result = check_fake_news(article)
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
