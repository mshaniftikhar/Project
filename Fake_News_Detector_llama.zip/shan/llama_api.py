import requests

API_URL = "https://api.together.xyz/v1/chat/completions"
API_KEY = "tgp_v1_kpN6r1tNqgrVrwosftbD3PSwnjx-DjVeNnaVCbKwF3k"

def check_fake_news(article):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    messages = [
    {
        "role": "system",
        "content": "You are a professional fake news detector. Analyze the article carefully and reply ONLY with 'Real' if it is trustworthy and factual, or 'Fake' if it contains misleading, false, or unverified claims. Do not guess. Be neutral."
    },
    {
        "role": "user",
        "content": f"Article: {article}"
    }
]


    data = {
        "model": "mistralai/Mistral-7B-Instruct-v0.1",
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 500
    }

    response = requests.post(API_URL, headers=headers, json=data)
    response.raise_for_status()

    return response.json()["choices"][0]["message"]["content"]
